"""
Router CXC — Conciliación de Cuentas por Cobrar
Integra: Fuerza Móvil + Profit Plus + API Mercantil Banco
URL: /ventas/cxc
"""
from fastapi import APIRouter, Request, Depends, Query, Body
from fastapi.responses import HTMLResponse, JSONResponse
from app.dependencies import get_current_user, templates
from app import models
from typing import Optional
import logging
from datetime import date, timedelta

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ventas/cxc", tags=["cxc"])


# ─────────────────────────────────────────────
# VISTAS HTML
# ─────────────────────────────────────────────

@router.get("", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
async def view_cxc(
    request: Request,
    user: models.User = Depends(get_current_user)
):
    """Panel principal de Conciliación CXC."""
    return templates.TemplateResponse("ventas/cxc.html", {
        "request": request,
        "title": "Conciliación CXC",
        "user": user,
    })


# ─────────────────────────────────────────────
# API — FUERZA MÓVIL
# ─────────────────────────────────────────────

@router.get("/api/fm/cobros")
async def api_cobros_fm(
    fecha_desde: Optional[str] = Query(None),
    fecha_hasta: Optional[str] = Query(None),
    cliente_id: Optional[str] = Query(None),
    vendedor_id: Optional[str] = Query(None),
    user: models.User = Depends(get_current_user),
):
    """Trae cobros de Fuerza Móvil."""
    try:
        from app.services.fuerza_movil_service import get_cobros
        if not fecha_desde:
            fecha_desde = (date.today() - timedelta(days=30)).isoformat()
        if not fecha_hasta:
            fecha_hasta = date.today().isoformat()
        cobros = get_cobros(fecha_desde, fecha_hasta, cliente_id, vendedor_id)
        return {"status": "ok", "total": len(cobros), "data": cobros}
    except Exception as e:
        logger.error(f"FM cobros error: {e}")
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


@router.get("/api/fm/status")
async def api_fm_status(user: models.User = Depends(get_current_user)):
    """Verifica el estado de la API de Fuerza Móvil."""
    try:
        from app.services.fuerza_movil_service import get_fm_status, discover_endpoints
        status = get_fm_status()
        return {"status": "ok", "fm": status}
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


@router.get("/api/fm/discover")
async def api_fm_discover(user: models.User = Depends(get_current_user)):
    """Descubre endpoints disponibles en Fuerza Móvil."""
    try:
        from app.services.fuerza_movil_service import discover_endpoints
        endpoints = discover_endpoints()
        return {"status": "ok", "endpoints": endpoints}
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


# ─────────────────────────────────────────────
# API — PROFIT (carmal_a)
# ─────────────────────────────────────────────

@router.get("/api/profit/facturas")
async def api_facturas_profit(
    cliente_id: str = Query(...),
    user: models.User = Depends(get_current_user),
):
    """Busca facturas pendientes de un cliente en Profit (carmal_a)."""
    try:
        from app.services.profit_cxc_service import get_resumen_cxc_cliente
        resumen = get_resumen_cxc_cliente(cliente_id)
        return {"status": "ok", "data": resumen}
    except Exception as e:
        logger.error(f"Profit facturas error: {e}")
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


@router.get("/api/profit/buscar")
async def api_buscar_cliente_profit(
    nombre: str = Query(...),
    user: models.User = Depends(get_current_user),
):
    """Busca facturas por nombre de cliente en Profit."""
    try:
        from app.services.profit_cxc_service import get_facturas_por_nombre
        facturas = get_facturas_por_nombre(nombre)
        return {"status": "ok", "total": len(facturas), "data": facturas}
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


@router.get("/api/profit/status")
async def api_profit_status(user: models.User = Depends(get_current_user)):
    """Verifica conectividad con Profit SQL Server."""
    try:
        from app.services.profit_cxc_service import test_connection
        ok = test_connection()
        return {"status": "ok" if ok else "offline", "connected": ok}
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


@router.get("/api/profit/schema")
async def api_profit_schema(user: models.User = Depends(get_current_user)):
    """Lista tablas de carmal_a para diagnóstico."""
    try:
        from app.services.profit_cxc_service import get_tables_schema
        tables = get_tables_schema()
        return {"status": "ok", "tables": tables}
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


# ─────────────────────────────────────────────
# API — BANCO MERCANTIL
# ─────────────────────────────────────────────

@router.post("/api/banco/consultar")
async def api_consultar_banco(
    body: dict = Body(...),
    user: models.User = Depends(get_current_user),
):
    """
    Consulta un movimiento en el Banco Mercantil.
    Body: { monto, tipo, telefono?, cedula?, referencia?, fecha_desde?, fecha_hasta? }
    """
    try:
        from app.services.banco_mercantil_service import buscar_movimiento_banco
        resultado = buscar_movimiento_banco(
            monto=float(body.get("monto", 0)),
            tipo=body.get("tipo", "c2p"),
            telefono=body.get("telefono", ""),
            cedula=body.get("cedula", ""),
            referencia=body.get("referencia", ""),
            fecha_desde=body.get("fecha_desde"),
            fecha_hasta=body.get("fecha_hasta"),
        )
        return {"status": "ok", "data": resultado}
    except Exception as e:
        logger.error(f"Banco consulta error: {e}")
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})


# ─────────────────────────────────────────────
# API — CONCILIACIÓN CRUZADA
# ─────────────────────────────────────────────

@router.post("/api/conciliar")
async def api_conciliar(
    body: dict = Body(...),
    user: models.User = Depends(get_current_user),
):
    """
    Conciliación completa de un cobro de Fuerza Móvil:
    1. Recibe datos del cobro FM
    2. Busca facturas en Profit
    3. Consulta banco
    4. Calcula estatus y tarea
    """
    try:
        from app.services.profit_cxc_service import get_resumen_cxc_cliente
        from app.services.banco_mercantil_service import buscar_movimiento_banco

        cliente_id = body.get("cliente_id", "")
        monto_fm   = float(body.get("monto_fm", 0))
        tipo_pago  = body.get("tipo_pago", "c2p")
        telefono   = body.get("telefono", "")
        cedula     = body.get("cedula", "")
        referencia = body.get("referencia", "")
        fecha      = body.get("fecha", "")

        # Paso 1: Profit
        profit_data = get_resumen_cxc_cliente(cliente_id) if cliente_id else {
            "total_facturas": 0, "total_adeudado": 0.0, "facturas": []
        }

        # Paso 2: Banco
        fecha_desde = fecha if fecha else None
        banco_data = buscar_movimiento_banco(
            monto=monto_fm,
            tipo=tipo_pago,
            telefono=telefono,
            cedula=cedula,
            referencia=referencia,
            fecha_desde=fecha_desde,
        )

        # Paso 3: Lógica de estatus y tarea
        monto_adeudado = profit_data.get("total_adeudado", 0.0)
        banco_confirmado = banco_data.get("confirmado", False)
        monto_banco = banco_data.get("monto_confirmado", 0.0)

        # Tolerancia de 0.5% para diferencias de redondeo
        tolerancia = max(monto_fm * 0.005, 0.01)

        if banco_confirmado and abs(monto_fm - monto_banco) <= tolerancia:
            estatus = "completado"
        elif banco_confirmado:
            estatus = "diferencia"
        else:
            estatus = "pendiente"

        # Tarea recomendada
        if estatus == "completado":
            if monto_fm >= monto_adeudado - tolerancia:
                tarea = "cobro_total"
            else:
                tarea = "abono"
        elif estatus == "diferencia":
            tarea = "abono"
        else:
            tarea = "adelanto"

        return {
            "status": "ok",
            "conciliacion": {
                "cliente_id": cliente_id,
                "monto_fm": monto_fm,
                "profit": profit_data,
                "banco": banco_data,
                "estatus": estatus,
                "tarea": tarea,
                "diferencia": round(abs(monto_fm - monto_banco), 2),
            }
        }
    except Exception as e:
        logger.error(f"Conciliación error: {e}")
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})
