"""
Servicio para consultar Profit Plus (SQL Server) - BD carmal_a en 192.168.60.15
Obtiene facturas pendientes de cobro por cliente para el módulo CXC.
"""
import pyodbc
import urllib.parse
import logging
from typing import List, Dict, Optional, Any
from decimal import Decimal
import os

logger = logging.getLogger(__name__)

# Conexión directa con pyodbc (sin SQLAlchemy) para evitar overhead en queries ad-hoc
PROFIT_HOST = os.getenv("SQLSRV_HOST_CXC", "192.168.60.15")
PROFIT_DB   = "carmal_a"
PROFIT_USER = "profit"
PROFIT_PWD  = "profit"

CONN_STR = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    f"SERVER={PROFIT_HOST};"
    f"DATABASE={PROFIT_DB};"
    f"UID={PROFIT_USER};"
    f"PWD={PROFIT_PWD};"
    "Encrypt=yes;"
    "TrustServerCertificate=yes;"
    "Connection Timeout=10;"
)


def _get_conn():
    """Crea y retorna una conexión pyodbc a Profit."""
    return pyodbc.connect(CONN_STR, timeout=10)


def test_connection() -> bool:
    """Verifica conectividad con el servidor Profit."""
    try:
        conn = _get_conn()
        cur = conn.cursor()
        cur.execute("SELECT 1")
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Profit connection test failed: {e}")
        return False


def get_facturas_por_cliente(cliente_id: str) -> List[Dict]:
    """
    Busca facturas pendientes de cobro de un cliente en carmal_a.
    Retorna lista de facturas con saldo pendiente.
    """
    try:
        conn = _get_conn()
        cur = conn.cursor()

        # Query para facturas pendientes de cobro (CxC)
        # Las tablas de Profit Plus típicas para CxC son:
        # cxcmovimiento / cxcmov — encabezado de cobros
        # factura / cxcFactura — facturas de venta
        # Ajustar según esquema real de carmal_a
        query = """
            SELECT TOP 50
                f.NROFACT       AS nro_factura,
                f.FECHA         AS fecha,
                f.CODCLIENTE    AS cod_cliente,
                ISNULL(c.NOMBRE, f.CODCLIENTE) AS nombre_cliente,
                ISNULL(f.MONTOTOTAL, 0)         AS monto_total,
                ISNULL(f.SALDO, ISNULL(f.MONTOTOTAL, 0)) AS saldo_pendiente,
                ISNULL(f.MONEDA, 'VES')         AS moneda,
                ISNULL(f.TIPODOC, 'FA')         AS tipo_doc,
                ISNULL(f.ESTATUS, 'P')          AS estatus
            FROM cxcmovimiento f
            LEFT JOIN cliente c ON c.CODCLIENTE = f.CODCLIENTE
            WHERE f.CODCLIENTE = ?
              AND ISNULL(f.SALDO, ISNULL(f.MONTOTOTAL, 0)) > 0
              AND ISNULL(f.TIPODOC, 'FA') NOT IN ('NC', 'ND', 'RC')
            ORDER BY f.FECHA DESC
        """
        cur.execute(query, (cliente_id,))
        rows = cur.fetchall()
        cols = [desc[0].lower() for desc in cur.description]
        conn.close()

        return [dict(zip(cols, row)) for row in rows]

    except pyodbc.ProgrammingError:
        # Si la tabla no existe, intentar tabla alternativa
        return _get_facturas_alt(cliente_id)
    except Exception as e:
        logger.error(f"Profit facturas error (cliente={cliente_id}): {e}")
        return []


def _get_facturas_alt(cliente_id: str) -> List[Dict]:
    """Intento alternativo con nombres de tabla comunes en Profit Plus."""
    alt_tables = [
        "ventas_encabezado", "sa_doc_ventas", "DocVenta", "factura",
        "cxcFac", "CXCMovimiento", "CXCMOV"
    ]
    for table in alt_tables:
        try:
            conn = _get_conn()
            cur = conn.cursor()
            cur.execute(
                f"SELECT TOP 1 * FROM {table} WHERE 1=0"
            )
            cols = [desc[0] for desc in cur.description]
            conn.close()
            logger.info(f"Profit: tabla alternativa encontrada: {table}, cols: {cols[:10]}")
            break
        except Exception:
            continue
    return []


def get_facturas_por_nombre(nombre_cliente: str) -> List[Dict]:
    """Busca facturas por nombre de cliente (búsqueda parcial)."""
    try:
        conn = _get_conn()
        cur = conn.cursor()
        query = """
            SELECT TOP 30
                f.NROFACT, f.FECHA, f.CODCLIENTE,
                ISNULL(c.NOMBRE, f.CODCLIENTE) AS nombre_cliente,
                ISNULL(f.MONTOTOTAL, 0)         AS monto_total,
                ISNULL(f.SALDO, ISNULL(f.MONTOTOTAL, 0)) AS saldo_pendiente,
                ISNULL(f.MONEDA, 'VES')         AS moneda,
                ISNULL(f.TIPODOC, 'FA')         AS tipo_doc
            FROM cxcmovimiento f
            LEFT JOIN cliente c ON c.CODCLIENTE = f.CODCLIENTE
            WHERE c.NOMBRE LIKE ?
              AND ISNULL(f.SALDO, ISNULL(f.MONTOTOTAL, 0)) > 0
            ORDER BY f.FECHA DESC
        """
        cur.execute(query, (f"%{nombre_cliente}%",))
        rows = cur.fetchall()
        cols = [desc[0].lower() for desc in cur.description]
        conn.close()
        return [dict(zip(cols, row)) for row in rows]
    except Exception as e:
        logger.error(f"Profit buscar por nombre error: {e}")
        return []


def get_resumen_cxc_cliente(cliente_id: str) -> Dict:
    """Retorna resumen de CxC de un cliente: total adeudado, facturas pendientes."""
    facturas = get_facturas_por_cliente(cliente_id)
    if not facturas:
        return {
            "cliente_id": cliente_id,
            "total_facturas": 0,
            "total_adeudado": 0.0,
            "moneda": "VES",
            "facturas": [],
        }

    total = sum(float(f.get("saldo_pendiente", 0) or 0) for f in facturas)
    moneda = facturas[0].get("moneda", "VES") if facturas else "VES"

    return {
        "cliente_id": cliente_id,
        "total_facturas": len(facturas),
        "total_adeudado": round(total, 2),
        "moneda": moneda,
        "facturas": [
            {
                "nro_factura": str(f.get("nro_factura", "")),
                "fecha": str(f.get("fecha", "")),
                "monto_total": float(f.get("monto_total", 0) or 0),
                "saldo_pendiente": float(f.get("saldo_pendiente", 0) or 0),
                "tipo_doc": str(f.get("tipo_doc", "FA")),
                "estatus": str(f.get("estatus", "P")),
            }
            for f in facturas
        ],
    }


def get_tables_schema() -> List[str]:
    """Lista tablas disponibles en carmal_a para diagnóstico."""
    try:
        conn = _get_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME
        """)
        tables = [row[0] for row in cur.fetchall()]
        conn.close()
        return tables
    except Exception as e:
        logger.error(f"Schema query error: {e}")
        return []
