"""
Servicio para consumir la API de Mercantil Banco (sandbox).
Busca movimientos bancarios (C2P, TDD, Transferencias) para conciliación CXC.
Ref: https://apimbu.mercantilbanco.com/mercantil-banco/sandbox/v1/
"""
import requests
import logging
import os
from typing import Optional, Dict, Any, List
from datetime import date, timedelta

logger = logging.getLogger(__name__)

MERCANTIL_BASE_URL = os.getenv(
    "MERCANTIL_API_URL",
    "https://apimbu.mercantilbanco.com/mercantil-banco/sandbox/v1"
)
MERCANTIL_CLIENT_ID = os.getenv("MERCANTIL_CLIENT_ID", "cambiame")

# Identificadores del comercio (sandbox)
MERCHANT_ID = {
    "integratorId": 31,
    "merchantId": 123456,
    "terminalId": "abcde",
}

CLIENT_IDENTIFY = {
    "ipaddress": "127.0.0.1",
    "browser_agent": "CarmalCXC/1.0",
    "mobile": {"manufacturer": "Server"},
}


def _post(path: str, payload: Dict) -> Optional[Dict]:
    """POST genérico a la API de Mercantil."""
    url = MERCANTIL_BASE_URL.rstrip("/") + path
    headers = {
        "X-IBM-Client-ID": MERCANTIL_CLIENT_ID,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=15)
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.HTTPError as e:
        logger.error(f"Mercantil HTTP error ({path}): {e} — {resp.text[:300]}")
        try:
            return resp.json()
        except Exception:
            return {"error": str(e), "status_code": resp.status_code}
    except Exception as e:
        logger.error(f"Mercantil error ({path}): {e}")
        return {"error": str(e)}


def buscar_pago_c2p(
    monto: float,
    telefono_destino: str,
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
) -> Dict:
    """
    Busca un pago C2P (Pago Móvil) en el banco.
    POST /mobile-payment/search
    """
    if not fecha_desde:
        fecha_desde = (date.today() - timedelta(days=7)).isoformat()
    if not fecha_hasta:
        fecha_hasta = date.today().isoformat()

    payload = {
        "merchant_identify": MERCHANT_ID,
        "client_identify": CLIENT_IDENTIFY,
        "search_by": {
            "amount": monto,
            "currency": "ves",
            "destinantion_mobile_number": telefono_destino,
            "date_from": fecha_desde,
            "date_to": fecha_hasta,
        },
    }
    result = _post("/mobile-payment/search", payload)
    return _normalize_banco_response(result, "c2p")


def buscar_pago_tarjeta(
    monto: float,
    numero_tarjeta_enc: str = "",
    referencia: str = "",
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
) -> Dict:
    """
    Busca un pago con tarjeta (TDD/TDC).
    POST /payment/search
    """
    if not fecha_desde:
        fecha_desde = (date.today() - timedelta(days=7)).isoformat()
    if not fecha_hasta:
        fecha_hasta = date.today().isoformat()

    payload = {
        "merchant_identify": MERCHANT_ID,
        "client_identify": CLIENT_IDENTIFY,
        "search_by": {
            "trx_type": "compra",
            "amount": monto,
            "currency": "ves",
            "date_from": fecha_desde,
            "date_to": fecha_hasta,
        },
    }
    if referencia:
        payload["search_by"]["reference"] = referencia

    result = _post("/payment/search", payload)
    return _normalize_banco_response(result, "tarjeta")


def buscar_transferencia(
    monto: float,
    cedula_origen: str = "",
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
) -> Dict:
    """
    Busca una transferencia bancaria.
    POST /payment/transfer-search
    """
    if not fecha_desde:
        fecha_desde = (date.today() - timedelta(days=7)).isoformat()
    if not fecha_hasta:
        fecha_hasta = date.today().isoformat()

    payload = {
        "merchant_identify": MERCHANT_ID,
        "client_identify": CLIENT_IDENTIFY,
        "search_by": {
            "amount": monto,
            "currency": "ves",
            "date_from": fecha_desde,
            "date_to": fecha_hasta,
        },
    }
    if cedula_origen:
        payload["search_by"]["origin_id"] = cedula_origen

    result = _post("/payment/transfer-search", payload)
    return _normalize_banco_response(result, "transferencia")


def buscar_movimiento_banco(
    monto: float,
    tipo: str = "c2p",
    telefono: str = "",
    cedula: str = "",
    referencia: str = "",
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
) -> Dict:
    """
    Función unificada que decide qué tipo de búsqueda realizar
    según el tipo de pago reportado por Fuerza Móvil.
    """
    tipo_lower = (tipo or "").lower()

    if "c2p" in tipo_lower or "movil" in tipo_lower or "pago_movil" in tipo_lower:
        return buscar_pago_c2p(monto, telefono, fecha_desde, fecha_hasta)
    elif "transfer" in tipo_lower:
        return buscar_transferencia(monto, cedula, fecha_desde, fecha_hasta)
    elif "tarjeta" in tipo_lower or "tdd" in tipo_lower or "tdc" in tipo_lower:
        return buscar_pago_tarjeta(monto, referencia=referencia, fecha_desde=fecha_desde, fecha_hasta=fecha_hasta)
    else:
        # Intentar C2P primero como más común
        result = buscar_pago_c2p(monto, telefono, fecha_desde, fecha_hasta)
        if not result.get("confirmado"):
            result = buscar_transferencia(monto, cedula, fecha_desde, fecha_hasta)
        return result


def _normalize_banco_response(data: Optional[Dict], tipo: str) -> Dict:
    """Normaliza la respuesta de Mercantil a un formato estándar."""
    if data is None:
        return {
            "confirmado": False,
            "tipo": tipo,
            "referencia_banco": "",
            "monto_confirmado": 0.0,
            "fecha_banco": "",
            "mensaje": "Sin respuesta del banco",
            "raw": None,
        }

    # Determinar si fue confirmado
    confirmado = False
    referencia = ""
    monto = 0.0
    fecha = ""
    mensaje = ""

    # Revisar campo de respuesta típico de Mercantil
    response_code = str(data.get("responseCode", data.get("response_code", data.get("code", "")))).strip()
    response_msg  = str(data.get("responseMessage", data.get("response_message", data.get("message", "")))).strip()

    # Códigos de éxito Mercantil: "00", "000", "approved"
    if response_code in ["00", "000", "0", "approved", "APPROVED", "success"]:
        confirmado = True
    elif "aprobad" in response_msg.lower() or "approved" in response_msg.lower():
        confirmado = True

    # Extraer referencia
    for key in ["referenceNumber", "reference_number", "reference", "nroReference", "trxId", "transaction_id"]:
        if key in data and data[key]:
            referencia = str(data[key])
            break

    # Extraer monto
    for key in ["amount", "monto", "valor"]:
        if key in data:
            try:
                monto = float(data[key])
                break
            except (TypeError, ValueError):
                pass

    # Extraer fecha
    for key in ["date", "fecha", "transactionDate", "transaction_date"]:
        if key in data:
            fecha = str(data[key])
            break

    mensaje = response_msg or f"Código: {response_code}"

    # Si hay lista de transacciones
    if "transactions" in data and isinstance(data["transactions"], list) and data["transactions"]:
        trx = data["transactions"][0]
        confirmado = True
        referencia = referencia or str(trx.get("reference", trx.get("referenceNumber", "")))
        monto = float(trx.get("amount", trx.get("monto", monto)) or monto)
        fecha = fecha or str(trx.get("date", trx.get("fecha", "")))

    return {
        "confirmado": confirmado,
        "tipo": tipo,
        "referencia_banco": referencia,
        "monto_confirmado": monto,
        "fecha_banco": fecha,
        "codigo_respuesta": response_code,
        "mensaje": mensaje,
        "raw": data,
    }
