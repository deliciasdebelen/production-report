"""
Servicio para consumir la API de Fuerza Móvil (FMDBELEN)
URL base: https://fmdbelen.ddns.net:9595/FMDBELEN/public/
"""
import requests
import urllib3
from datetime import datetime, date, timedelta
from typing import Optional, List, Dict, Any
import logging

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

FM_BASE_URL = "https://fmdbelen.ddns.net:9595/FMDBELEN/public"
FM_TIMEOUT = 15

# Endpoints conocidos de Fuerza Móvil (se descubren dinámicamente si no responden)
FM_ENDPOINTS = {
    "cobros": "/cobros",
    "recibos": "/recibos",
    "clientes": "/clientes",
    "movimientos": "/movimientos",
    "pagos": "/pagos",
    "facturas": "/facturas",
    "vendedores": "/vendedores",
}

def _get(path: str, params: dict = None) -> Optional[Any]:
    """GET genérico contra la API de Fuerza Móvil con TLS legacy."""
    url = FM_BASE_URL.rstrip("/") + path
    try:
        resp = requests.get(
            url,
            params=params or {},
            verify=False,
            timeout=FM_TIMEOUT,
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.SSLError:
        # Intentar con adapter legacy TLS
        try:
            session = requests.Session()
            resp = session.get(
                url,
                params=params or {},
                verify=False,
                timeout=FM_TIMEOUT,
                headers={"Accept": "application/json"},
            )
            if resp.status_code == 200:
                try:
                    return resp.json()
                except Exception:
                    return {"raw": resp.text}
        except Exception as e2:
            logger.error(f"FM SSL retry error: {e2}")
    except requests.exceptions.ConnectionError as e:
        logger.error(f"FM connection error ({path}): {e}")
    except requests.exceptions.Timeout:
        logger.error(f"FM timeout ({path})")
    except Exception as e:
        logger.error(f"FM error ({path}): {e}")
    return None


def discover_endpoints() -> Dict[str, Any]:
    """Intenta descubrir endpoints disponibles en la API de FM."""
    results = {}
    for name, path in FM_ENDPOINTS.items():
        data = _get(path)
        results[name] = {
            "available": data is not None,
            "sample": data if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict)
                      else (data if isinstance(data, dict) else None)
        }
    return results


def get_cobros(
    fecha_desde: Optional[str] = None,
    fecha_hasta: Optional[str] = None,
    cliente_id: Optional[str] = None,
    vendedor_id: Optional[str] = None,
) -> List[Dict]:
    """
    Obtiene los cobros/recibos de Fuerza Móvil.
    Intenta múltiples endpoints hasta encontrar el correcto.
    Retorna lista normalizada de cobros.
    """
    if not fecha_desde:
        fecha_desde = (date.today() - timedelta(days=30)).isoformat()
    if not fecha_hasta:
        fecha_hasta = date.today().isoformat()

    params = {}
    if fecha_desde:
        params["desde"] = fecha_desde
        params["fecha_inicio"] = fecha_desde
        params["start"] = fecha_desde
    if fecha_hasta:
        params["hasta"] = fecha_hasta
        params["fecha_fin"] = fecha_hasta
        params["end"] = fecha_hasta
    if cliente_id:
        params["cliente"] = cliente_id
        params["cliente_id"] = cliente_id
    if vendedor_id:
        params["vendedor"] = vendedor_id

    # Intenta distintos endpoints en orden
    for path in ["/cobros", "/recibos", "/pagos", "/movimientos"]:
        data = _get(path, params)
        if data is not None:
            return _normalize_cobros(data, path)

    logger.warning("FM: No se pudo obtener cobros de ningún endpoint")
    return []


def _normalize_cobros(data: Any, source_path: str) -> List[Dict]:
    """Normaliza la respuesta de FM a un formato estándar."""
    if data is None:
        return []

    # Si es dict con lista dentro
    if isinstance(data, dict):
        for key in ["data", "cobros", "recibos", "pagos", "results", "items", "registros"]:
            if key in data and isinstance(data[key], list):
                data = data[key]
                break
        if isinstance(data, dict):
            return [_map_cobro(data, source_path)]

    if not isinstance(data, list):
        return []

    return [_map_cobro(item, source_path) for item in data if isinstance(item, dict)]


def _map_cobro(item: Dict, source_path: str) -> Dict:
    """Mapea un item de FM a estructura estándar de cobro."""
    def _get_field(d, *keys):
        for k in keys:
            if k in d:
                return d[k]
        return None

    return {
        "fm_id": str(_get_field(item, "id", "ID", "codigo", "Codigo", "recibo", "numero") or ""),
        "fecha": str(_get_field(item, "fecha", "Fecha", "date", "fecha_cobro", "created_at") or ""),
        "cliente_id": str(_get_field(item, "cliente_id", "ClienteId", "id_cliente", "cod_cliente", "CodigoCliente") or ""),
        "cliente_nombre": str(_get_field(item, "cliente", "Cliente", "nombre_cliente", "NombreCliente", "razon_social") or ""),
        "monto": float(_get_field(item, "monto", "Monto", "amount", "importe", "total", "Total") or 0),
        "referencia": str(_get_field(item, "referencia", "Referencia", "ref", "numero_ref", "nro_referencia") or ""),
        "vendedor_id": str(_get_field(item, "vendedor_id", "VendedorId", "id_vendedor", "cod_vendedor") or ""),
        "vendedor_nombre": str(_get_field(item, "vendedor", "Vendedor", "nombre_vendedor", "NombreVendedor") or ""),
        "tipo_pago": str(_get_field(item, "tipo_pago", "TipoPago", "forma_pago", "metodo_pago", "tipo") or ""),
        "banco": str(_get_field(item, "banco", "Banco", "banco_origen") or ""),
        "telefono": str(_get_field(item, "telefono", "Telefono", "phone", "celular", "movil") or ""),
        "cedula": str(_get_field(item, "cedula", "Cedula", "rif", "dni", "documento") or ""),
        "moneda": str(_get_field(item, "moneda", "Moneda", "currency", "divisa") or "VES"),
        "_source": source_path,
        "_raw": item,
    }


def get_clientes_fm() -> List[Dict]:
    """Obtiene lista de clientes de Fuerza Móvil."""
    data = _get("/clientes")
    if not data:
        return []
    if isinstance(data, dict):
        for k in ["data", "clientes", "results"]:
            if k in data:
                data = data[k]
                break
    if isinstance(data, list):
        return data
    return []


def get_fm_status() -> Dict:
    """Verifica el estado de la API de Fuerza Móvil."""
    data = _get("/")
    if data is not None:
        return {"status": "online", "data": data}
    return {"status": "offline", "data": None}
