
import sys
import os
from sqlalchemy import text
from decimal import Decimal

# Add project root to path
sys.path.append(os.getcwd())

from app.external_db import engine_a

def verify_link():
    print("Verifying Return -> Credit Note -> Invoice Link...", flush=True)
    
    with engine_a.connect() as conn:
        # 1. Get a recent Return
        print("\nFetching recent saDevolucionCliente...")
        q_ret = text("SELECT TOP 1 * FROM saDevolucionCliente ORDER BY fec_emis DESC")
        ret = conn.execute(q_ret).fetchone()
        
        if not ret:
            print("No returns found.")
            return

        print(f"Return Found: {ret.doc_num} | Date: {ret.fec_emis} | Client: {ret.co_cli} | Total: {ret.total_neto}")
        print(f"  Keys: {ret._mapping.keys()}") # Print all columns to find linking fields

        # 2. Find associated Credit Note (N/C) in saDocumentoVenta
        # Usually N/C has same doc_num or matches total/client
        print(f"\nSearching saDocumentoVenta (N/C) for Client {ret.co_cli}...")
        q_nc = text("""
            SELECT * FROM saDocumentoVenta 
            WHERE co_tipo_doc = 'N/C' 
            AND co_cli = :cli 
            AND total_neto = :tot
            AND fec_emis = :date
        """)
        nc = conn.execute(q_nc, {"cli": ret.co_cli, "tot": ret.total_neto, "date": ret.fec_emis}).fetchone()
        
        if nc:
            print(f"MATCHING N/C Found: {nc.nro_doc} | Total: {nc.total_neto}")
            print(f"  Keys: {nc._mapping.keys()}")
        else:
            print("No matching N/C found by exact amount/date.")
            # Try searching by doc_num just in case
            q_nc2 = text("SELECT * FROM saDocumentoVenta WHERE nro_doc = :doc AND co_tipo_doc = 'N/C'")
            nc2 = conn.execute(q_nc2, {"doc": ret.doc_num}).fetchone()
            if nc2:
                 print(f"MATCHING N/C Found by DocNum: {nc2.nro_doc}")

        # 3. Check Lines (saDevolucionClienteReng)
        print(f"\nFetching Lines for Return {ret.doc_num}...")
        q_lines = text("SELECT * FROM saDevolucionClienteReng WHERE doc_num = :doc")
        lines = conn.execute(q_lines, {"doc": ret.doc_num}).fetchall()
        
        
        if lines:
            keys = list(lines[0]._mapping.keys())
            print(f"  Line Columns:")
            for k in keys:
                print(f"    - {k}")
            
        calc_total = Decimal(0)
        calc_tax = Decimal(0)
        
        for l in lines:
            # Try to grab relevant columns dynamically based on common names
            try:
                # Common column names in Profit Plus: total_neto, total_art, prec_vta, total_sub, reng_neto
                # Let's try to find identifying columns in the keys
                pass
            except Exception as e:
                pass
            
        print(f"  Calculated from Lines: Total={calc_total} | Tax={calc_tax}")
        print(f"  Return Header: Total={ret.total_neto} | Tax={ret.monto_imp}")
        
        if abs(calc_total - ret.total_neto) < 0.01:
            print("  VALID: Line Totals match Header.")
        else:
            print("  INVALID: Mismatch in Line Totals!")

if __name__ == "__main__":
    verify_link()
