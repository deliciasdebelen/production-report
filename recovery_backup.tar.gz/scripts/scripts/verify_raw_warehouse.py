
import sys
import os
from sqlalchemy import text

# Add project root to path
sys.path.append(os.getcwd())

try:
    from app.external_db import engine_a
    print("Successfully imported engine_a", flush=True)
except ImportError as e:
    print(f"Failed to import engine_a: {e}")
    sys.exit(1)

def check_raw():
    guids = [
        '62EF63AC-D41A-462D-B37F-D0ECCAF47264',
        '57E79747-7C54-4A37-A661-6927AD8CE988',
        '609D0DF5-9C4C-47F0-9538-3C14B993875B'
    ]

    print(f"\n--- VERIFYING RAW DATA ---\n", flush=True)

    with engine_a.connect() as conn:
        for guid in guids:
            query = text(f"""
                SELECT rowguid, numero_lote, co_alma 
                FROM saLoteSalida 
                WHERE rowguid = '{guid}' OR rowguid_reng = '{guid}'
            """)
            row = conn.execute(query).fetchone()
            if row:
                print(f"GUID: {guid} | Lot: {row[1]} | Alma: '{row[2]}'")
            else:
                print(f"GUID: {guid} NOT FOUND")

if __name__ == "__main__":
    check_raw()
