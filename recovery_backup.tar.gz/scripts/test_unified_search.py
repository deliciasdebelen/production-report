import pyodbc
import json

server = "192.168.1.205"
user = "PROFIT"
password = "profit"
database = "carmal_a"

conn_str = (
    f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    f"SERVER={server};"
    f"DATABASE={database};"
    f"UID={user};"
    f"PWD={password};"
    "Encrypt=yes;"
    "TrustServerCertificate=yes;"
)

def test_search(q):
    print(f"Searching for '{q}'...")
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        
        search_val = f"%{q}%"
        
        # Invoices
        print("Searching Invoices...")
        sql_inv = """
            SELECT TOP 5 'invoice' as doc_type, f.doc_num, f.descrip AS invoice_desc, c.cli_des AS client_name 
            FROM saFacturaVenta f
            LEFT JOIN saCliente c ON f.co_cli = c.co_cli
            WHERE (f.doc_num LIKE ? OR c.cli_des LIKE ?)
            ORDER BY f.doc_num DESC
        """
        cursor.execute(sql_inv, (search_val, search_val))
        rows = cursor.fetchall()
        for r in rows:
            print(f" - {r.doc_num}: {r.client_name}")
            
        # Delivery Notes
        print("\nSearching Delivery Notes...")
        sql_ne = """
            SELECT TOP 5 'delivery_note' as doc_type, f.doc_num, f.descrip AS invoice_desc, c.cli_des AS client_name 
            FROM saNotaEntregaVenta f
            LEFT JOIN saCliente c ON f.co_cli = c.co_cli
            WHERE (f.doc_num LIKE ? OR c.cli_des LIKE ?)
            ORDER BY f.doc_num DESC
        """
        cursor.execute(sql_ne, (search_val, search_val))
        rows = cursor.fetchall()
        for r in rows:
            print(f" - {r.doc_num}: {r.client_name}")
            
        conn.close()
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_search("P") # Test with a common letter
