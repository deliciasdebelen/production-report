
import sys
import os
from sqlalchemy import text
# from termcolor import colored

# Add project root to path
sys.path.append(os.getcwd())

try:
    from app.external_db import engine_a
    print("Successfully imported engine_a")
except ImportError as e:
    print(f"Failed to import engine_a: {e}")
    sys.exit(1)

def run_debug():
    article = "PT01P01X013"
    lot = "L1 260114-01"

    print(f"\n--- Identifying Records for Article: {article}, Lot: {lot} ---\n")

    with engine_a.connect() as conn:
        try:
            query = text(f"""
                SELECT reng_num, tipo_doc, co_art, co_alma, numero_lote, fecha_inicio, stock_actual, rowguid
                FROM saLoteEntrada 
                WHERE co_art = '{article}' AND numero_lote = '{lot}'
            """)
            results = conn.execute(query).fetchall()
            
            if results:
                 print(f"{'Reng':<8} {'Tipo':<6} {'Stock':<12} {'Fecha':<20} {'GUID'}")
                 print("-" * 80)
                 for r in results:
                     # r indices: reng_num(0), tipo_doc(1), ..., stock_actual(6), rowguid(7)
                     # Adjust indices based on the SELECT order above
                     print(f"{r[0]:<8} {r[1]:<6} {r[6]:<12} {str(r[5]):<20} {r[7]}")
            else:
                 print("No records found in saLoteEntrada for this lot.")

        except Exception as e:
            print(f"Error executing query: {e}")

if __name__ == "__main__":
    run_debug()
